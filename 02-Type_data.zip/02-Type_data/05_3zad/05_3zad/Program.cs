﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_3zad
{
    class Program
    {
        static void Main(string[] args)
        {
            string chislo16 = Console.ReadLine();
            int chislo10 = Convert.ToInt32(chislo16, 16);
            Console.WriteLine(chislo10);
            Console.ReadLine();
        }
    }
}
