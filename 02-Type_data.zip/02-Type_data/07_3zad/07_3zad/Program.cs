﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_3zad
{
    class Program
    {
        static void Main(string[] args)
        {
            string niz = Console.ReadLine();
            Convert.ToBoolean(niz);
            if(niz=="True")
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
            Console.ReadKey();
        }
    }
}
