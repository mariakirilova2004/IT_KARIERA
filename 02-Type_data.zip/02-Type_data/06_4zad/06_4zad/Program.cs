﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_4zad
{
    class Program
    {
        static void Main(string[] args)
        {
            float m = float.Parse(Console.ReadLine());
            float h = float.Parse(Console.ReadLine());
            float mm = float.Parse(Console.ReadLine());
            float s = float.Parse(Console.ReadLine());
            float ms = m / (h*3600+mm*60+s);
            float kmh = (m / 1000) / ((h * 3600 + mm * 60 + s) / 3600);
            float mp = m / 1609;
            float mph =mp/ ((h * 3600 + mm * 60 + s) / 3600);
            Console.WriteLine(ms);
            Console.WriteLine(kmh);
            Console.WriteLine(mph);
            Console.ReadKey();
        }
    }
}
