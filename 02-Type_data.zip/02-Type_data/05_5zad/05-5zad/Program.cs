﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_5zad
{
    class Program
    {
        static void Main(string[] args)
        {
            int chislo = int.Parse(Console.ReadLine());
            string dvoichno = Convert.ToString(chislo, 2);
            string shestndesetichno = Convert.ToString(chislo, 16);
            shestndesetichno.ToUpper();
            Console.WriteLine(shestndesetichno);
            Console.WriteLine(dvoichno);
            Console.ReadKey();
        }
    }
}
