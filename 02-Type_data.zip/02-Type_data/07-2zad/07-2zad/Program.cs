﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_2zad
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            for(int i=1;i<=num;i++)
            {
                int num1 =i;
            int sum = num1 % 10;
            num1 = num1 / 10;
            sum += num1;
            if(sum==5 || sum==7 || sum==11)
            {
                Console.WriteLine($"{i} -> True");
            }
                else
                {
                    Console.WriteLine($"{i} -> False");
                }
            }
            
            Console.ReadKey();
        }
    }
}
