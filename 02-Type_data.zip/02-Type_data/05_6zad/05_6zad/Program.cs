﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_6zad
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int sum = 0;
            for(int i=1;i<=a;i++)
            {
                int chislo1 = int.Parse(Console.ReadLine());
                int chislo2 = int.Parse(Console.ReadLine());
                sum += chislo1 % chislo2;
            }
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
