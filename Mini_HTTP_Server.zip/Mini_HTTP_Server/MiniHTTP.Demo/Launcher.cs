﻿using MiniHTTP.HTTP.Enums;
using MiniHTTP.WebServer;
using MiniHTTP.WebServer.Routing;
using System;

namespace MiniHTTP.Demo
{ 
    public class Launcher
    {
        static void Main(string[] args)
        {
            IServerRoutingTable serverRoutingTable = new ServerRoutingTable();

            serverRoutingTable.Add(HttpRequestMethod.Get, "/", request => new HomeController().Index(request));

            Server server = new Server(port: 8000, serverRoutingTable);

            server.Run();
        }
    }
}