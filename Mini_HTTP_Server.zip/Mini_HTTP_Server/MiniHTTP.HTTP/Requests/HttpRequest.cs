﻿using MiniHTTP.HTTP.Common;
using MiniHTTP.HTTP.Enums;
using MiniHTTP.HTTP.Exceptions;
using MiniHTTP.HTTP.Extensions;
using MiniHTTP.HTTP.Headers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniHTTP.HTTP.Requests
{
    public class HttpRequest : IHttpRequest
    {
        public HttpRequest(string requestString)
        {
            CoreValidator.ThrowIfNullOrEmpty(requestString, nameof(requestString));

            this.FormData = new Dictionary<string, object>();
            this.QueryData = new Dictionary<string, object>();
            this.Headers = new HttpHeaderCollection();

            this.ParseRequest(requestString);
        }
        public string Path { get; private set; }

        public string Url { get; private set; }

        public Dictionary<string, object> FormData { get; }

        public Dictionary<string, object> QueryData { get; }

        public IHttpHeaderCollection Headers { get; }

        public HttpRequestMethod RequestMethod { get; private set; }

        private void ParseRequest(string requestString)
        {
            string[] splitRequestContent = requestString
                .Split(new[] { GlobalConstants.HttpNewLine }, StringSplitOptions.None);

            string[] requestLine = splitRequestContent[0].Trim().
                Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (!this.IsValidRequestLine(requestLine))
            {
                throw new BadRequestException();
            }

            this.ParseRequestMethod(requestLine);
            this.ParseRequestUrl(requestLine);
            this.ParseRequestPath();

            this.ParseHeaders(splitRequestContent.Skip(1).ToArray());
            this.ParseCookies();

            this.ParseRequestParameters(splitRequestContent[splitRequestContent.Length - 1]);
        }
        private bool IsValidRequestLine(string[] requestLine)
        {
            return requestLine.Length == 3 && requestLine[2] == "HTTP/1.1";
        }

        private bool IsValidRequestQueryString(string queryString, string[] queryParameters)
        {
            return !string.IsNullOrEmpty(queryString) && queryParameters.Length >= 1;
        }
        private void ParseRequestMethod(string[] requestLine)
        {
            this.RequestMethod = Enum.Parse<HttpRequestMethod>(StringExtensions.Capitalize(requestLine[0])); 
        }

        private void ParseRequestUrl(string[] requestLine)
        {
            this.Url = requestLine[1];
        }

        private void ParseRequestPath()
        {
            this.Path = this.Url.Substring(0, this.Url.IndexOf('?'));
        }

        private void ParseHeaders(string[] requestContent)
        {
            foreach (var header in requestContent)
            {
                string[] parts = header.Split(": ").ToArray();
                this.Headers.AddHeader(new HttpHeader(parts[0], parts[1]));
            }

            if (this.Headers.ContainsHeader("Host")) throw new BadRequestException();
        }

        private void ParseCookies()
        {
            throw new NotImplementedException();
        }

        private void ParseQueryParameters()
        {
            string queryString = this.Url.Substring(this.Url.IndexOf('?') + 1, this.Url.Length);
            string[] queryParameters = queryString.Split(new[] {'&', ' '}).ToArray();
            if (!IsValidRequestQueryString(queryString, queryParameters))
            {
                if (!string.IsNullOrEmpty(queryString) && queryParameters.Length == 0) throw new BadRequestException();
                else return;
            }
            else
            {
                foreach (var query in queryParameters)
                {
                    string[] parts = query.Split("=").ToArray();
                    this.QueryData.Add(parts[0], parts[1]);
                }
            }
        }

        private void ParseFormDataParameters(string formData)
        {
            string[] formParameters = formData.Split(new[] { '&' }).ToArray();
            if (!IsValidRequestQueryString(formData, formParameters))
            {
                return;
            }
            else
            {
                foreach (var form in formParameters)
                {
                    string[] parts = form.Split("=").ToArray();
                    this.FormData.Add(parts[0], parts[1]);
                }
            }
        }

        private void ParseRequestParameters(string formData)
        {
            ParseQueryParameters();
            ParseFormDataParameters(formData);
        }
    }
}
