﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniHTTP.HTTP.Extensions
{
    public static class StringExtensions
    {
        public static string Capitalize(string text)
        {
            return text[0].ToString().ToUpper() + text?.Skip(1)?.ToString()?.ToLower();
        }
    }
}
