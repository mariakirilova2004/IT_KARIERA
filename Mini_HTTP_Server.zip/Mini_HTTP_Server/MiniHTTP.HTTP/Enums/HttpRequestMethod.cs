﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniHTTP.HTTP.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}
